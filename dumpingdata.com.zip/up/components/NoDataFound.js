export default function NoDataFound(){
    return(
        <div className="text-center">
          <p className="text-white  text-sm sm:text-md md:text-lg lg:text-xl xl:text-2xl  p-5 font-serif">
              No Data Found!!
           </p>
        </div>
    )
}